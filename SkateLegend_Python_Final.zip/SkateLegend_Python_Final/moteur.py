"""
moteur.py — Moteur de jeu Skate Legend.
Syntaxe L1 : dictionnaires, fonctions simples, pas de classes.
"""

import random
import copy
from cartes import CATALOGUE_FIGURES, CATALOGUE_LEGENDAIRES

NB_MANCHES = 4


# ─────────────────────────────────────────────────────────────────
#  Création d'un joueur
# ─────────────────────────────────────────────────────────────────

def creer_joueur(id_joueur):
    return {
        "id":                  id_joueur,
        "en_jeu":              True,
        "points":              0,
        "casques_reserve":     0,
        "casque_actuel":       None,
        "enchainement_actuel": [],
        "main":                [],
    }


# ─────────────────────────────────────────────────────────────────
#  Initialisation
# ─────────────────────────────────────────────────────────────────

def nouvelle_partie(nb_joueurs, graine=None):
    if graine is not None:
        random.seed(graine)

    figures = copy.deepcopy(CATALOGUE_FIGURES)
    random.shuffle(figures)
    milieu = len(figures) // 2
    pile0  = figures[:milieu]
    pile1  = figures[milieu:]

    legendaires    = copy.deepcopy(CATALOGUE_LEGENDAIRES)
    perfect        = legendaires[0]
    pool           = legendaires[1:]
    random.shuffle(pool)
    pile_recompense = pool[:3] + [perfect]

    joueurs = [creer_joueur(i) for i in range(nb_joueurs)]

    # Distribue 1 carte à chaque joueur
    for joueur in joueurs:
        if pile0:
            joueur["main"].append(pile0.pop())

    idx_debut = random.randint(0, nb_joueurs - 1)

    return {
        "joueurs":            joueurs,
        "id_manche":          1,
        "cartes_legendaires": pile_recompense,
        "pioche":             [None, None],
        "_pile0":             pile0,
        "_pile1":             pile1,
        "_defausse":          [],
        "_idx_courant":       idx_debut,
        "_idx_debut_manche":  idx_debut,
        "_manche_finie":      False,
        "moi":                joueurs[idx_debut],
    }


# ─────────────────────────────────────────────────────────────────
#  Pioches
# ─────────────────────────────────────────────────────────────────

def _piocher(etat, numero_pile):
    """Pioche la carte du dessus (1=gauche, 2=droite)."""
    cle = "_pile0" if numero_pile == 1 else "_pile1"
    idx = 0 if numero_pile == 1 else 1

    if not etat[cle]:
        _recharger_pioches(etat)

    if not etat[cle]:
        return None

    carte = etat[cle].pop()
    etat["pioche"][idx] = None
    return carte


def _recharger_pioches(etat):
    p0    = etat["_pile0"]
    p1    = etat["_pile1"]
    vide0 = len(p0) == 0
    vide1 = len(p1) == 0

    if not vide0 and not vide1:
        return

    if not vide0 and vide1:
        milieu        = len(p0) // 2
        etat["_pile1"] = p0[:milieu]
        etat["_pile0"] = p0[milieu:]
    elif vide0 and not vide1:
        milieu        = len(p1) // 2
        etat["_pile0"] = p1[:milieu]
        etat["_pile1"] = p1[milieu:]
    else:
        d = etat["_defausse"]
        if d:
            random.shuffle(d)
            milieu        = len(d) // 2
            etat["_pile0"] = d[:milieu]
            etat["_pile1"] = d[milieu:]
            etat["_defausse"] = []


# ─────────────────────────────────────────────────────────────────
#  Règles
# ─────────────────────────────────────────────────────────────────

def _verifier_chute(joueur):
    enc    = joueur["enchainement_actuel"]
    casque = joueur["casque_actuel"]

    # Condition 1 : 3 Skate Cassé
    if sum(1 for c in enc if c["cassé"] == 1) >= 3:
        return True

    # Condition 2 : 3 cartes même couleur
    compteur = {}
    for carte in enc:
        col = carte["couleur"]
        if col is None or col == casque:
            continue
        compteur[col] = compteur.get(col, 0) + 1
        if compteur[col] >= 3:
            return True

    return False


def _appliquer_chute(joueur, etat):
    for carte in joueur["enchainement_actuel"]:
        etat["_defausse"].append(carte)
    joueur["enchainement_actuel"] = []
    joueur["casque_actuel"]       = None
    joueur["en_jeu"]              = False
    joueur["casques_reserve"]     += 1


def _valider_enchainement(joueur):
    points_gagnes = 0
    for carte in joueur["enchainement_actuel"]:
        if carte["condition"] is not None:
            if _condition_remplie(carte, joueur["enchainement_actuel"]):
                points_gagnes += carte["récompense"]
        else:
            points_gagnes += carte["récompense"]

    joueur["points"]               += points_gagnes
    joueur["enchainement_actuel"]   = []
    joueur["casque_actuel"]         = None
    joueur["en_jeu"]                = False
    return points_gagnes


def _condition_remplie(carte_leg, enchainement):
    cond = carte_leg["condition"]
    if cond is None:
        return True
    if cond == "2 rouges":
        return sum(1 for c in enchainement if c["couleur"] == "rouge") >= 2
    if cond == "2 meme couleur":
        cpt = {}
        for c in enchainement:
            col = c["couleur"]
            if col:
                cpt[col] = cpt.get(col, 0) + 1
                if cpt[col] >= 2:
                    return True
        return False
    if cond == "4 cartes":
        return len(enchainement) >= 4
    if cond == "5 cartes":
        return len(enchainement) >= 5
    if cond == "1 vert 1 jaune":
        couleurs = {c["couleur"] for c in enchainement}
        return "vert" in couleurs and "jaune" in couleurs
    if cond == "3 couleurs":
        couleurs = {c["couleur"] for c in enchainement if c["couleur"]}
        return len(couleurs) >= 3
    if cond == "2 casses":
        return sum(1 for c in enchainement if c["cassé"] == 1) >= 2
    return False


# ─────────────────────────────────────────────────────────────────
#  etat_partie public (format professeur)
# ─────────────────────────────────────────────────────────────────

def _construire_etat_public(etat, id_joueur):
    joueurs_publics = []
    for j in etat["joueurs"]:
        joueurs_publics.append({
            "id":                  j["id"],
            "en_jeu":              j["en_jeu"],
            "points":              j["points"],
            "casques_reserve":     j["casques_reserve"],
            "casque_actuel":       j["casque_actuel"],
            "rejouer":             0,
            "piocher":             0,
            "enchainement_actuel": list(j["enchainement_actuel"]),
        })

    j_courant = etat["joueurs"][id_joueur]
    moi = {
        "id":                  j_courant["id"],
        "en_jeu":              j_courant["en_jeu"],
        "points":              j_courant["points"],
        "casques_reserve":     j_courant["casques_reserve"],
        "casque_actuel":       j_courant["casque_actuel"],
        "enchainement_actuel": list(j_courant["enchainement_actuel"]),
        "rejouer":             0,
        "piocher":             0,
        "main":                list(j_courant["main"]),
    }

    return {
        "joueurs":            joueurs_publics,
        "id_manche":          etat["id_manche"],
        "cartes_legendaires": list(etat["cartes_legendaires"]),
        "pioche":             list(etat["pioche"]),
        "moi":                moi,
    }


# ─────────────────────────────────────────────────────────────────
#  Tour d'un joueur
# ─────────────────────────────────────────────────────────────────

def jouer_tour(etat, strategie):
    idx    = etat["_idx_courant"]
    joueur = etat["joueurs"][idx]

    # Joueur déjà sorti cette manche → passe directement
    if not joueur["en_jeu"]:
        _avancer_idx(etat)
        return

    etat_public = _construire_etat_public(etat, idx)
    rejouer     = True

    while rejouer:
        rejouer = False

        continuer = strategie.continuer_jouer(idx, etat_public)

        if not continuer:
            # S'ARRÊTER
            _valider_enchainement(joueur)
            strategie.notifier_choix(idx, False, None, etat_public)
            break

        # Choisit et pioche une carte
        source = strategie.jouer_carte(idx, etat_public)
        carte  = _obtenir_carte(source, joueur, etat)

        if carte is None:
            # Plus de carte disponible : force l'arrêt
            _valider_enchainement(joueur)
            break

        joueur["enchainement_actuel"].append(carte)
        strategie.notifier_choix(idx, True, carte, etat_public)

        # Vérifie la chute
        if _verifier_chute(joueur):
            _appliquer_chute(joueur, etat)
            break

        # Propose le casque
        if joueur["casques_reserve"] > 0 and joueur["casque_actuel"] is None:
            etat_public = _construire_etat_public(etat, idx)
            if strategie.jouer_casque(idx, etat_public):
                joueur["casques_reserve"] -= 1
                joueur["casque_actuel"]    = carte["couleur"]

        # Applique l'effet de la carte
        etat_public = _construire_etat_public(etat, idx)

        if carte["piocher"] == 1:
            source_p    = strategie.piocher_carte(idx, etat_public)
            carte_bonus = _piocher(etat, source_p[0])
            if carte_bonus is not None:
                joueur["main"].append(carte_bonus)
                vis = etat["pioche"][source_p[0] - 1]
                strategie.notifier_pioche(idx, vis)

        elif carte["visible"] == 1:
            # Révèle la pile gauche si non vide, sinon droite
            if etat["_pile0"]:
                etat["pioche"][0] = etat["_pile0"][-1]
            elif etat["_pile1"]:
                etat["pioche"][1] = etat["_pile1"][-1]

        elif carte["rejouer"] == 1:
            etat_public = _construire_etat_public(etat, idx)
            rejouer     = True   # rejoue immédiatement
            continue

        etat_public = _construire_etat_public(etat, idx)

    etat["moi"] = joueur
    _avancer_idx(etat)


def _obtenir_carte(source, joueur, etat):
    pile, idx = source
    if pile == 1:
        return _piocher(etat, 1)
    elif pile == 2:
        return _piocher(etat, 2)
    elif pile == 0:
        if 0 <= idx < len(joueur["main"]):
            return joueur["main"].pop(idx)
    return None


def _avancer_idx(etat):
    """Passe au joueur actif suivant, ou déclenche la fin de manche."""
    joueurs = etat["joueurs"]
    n       = len(joueurs)
    idx     = etat["_idx_courant"]

    # Cherche le prochain joueur encore en jeu
    nb_essais = 0
    prochain  = (idx + 1) % n
    while not joueurs[prochain]["en_jeu"] and nb_essais < n:
        prochain  = (prochain + 1) % n
        nb_essais += 1

    if nb_essais >= n or not joueurs[prochain]["en_jeu"]:
        # Tous les joueurs ont terminé → fin de manche
        etat["_manche_finie"] = True
        _terminer_manche(etat)
    else:
        etat["_idx_courant"] = prochain
        etat["moi"]          = joueurs[prochain]


def _terminer_manche(etat):
    joueurs = etat["joueurs"]

    # Jetons casque non utilisés → +2 pts chacun
    for j in joueurs:
        j["points"]        += j["casques_reserve"] * 2
        j["casques_reserve"] = 0

    # Donne la récompense au joueur avec le plus de points
    if etat["cartes_legendaires"]:
        meilleur = max(joueurs, key=lambda j: j["points"])
        recompense = etat["cartes_legendaires"].pop(0)
        meilleur["main"].append(recompense)

    # Prépare la manche suivante
    if etat["id_manche"] < NB_MANCHES:
        etat["id_manche"]     += 1
        etat["_manche_finie"]  = False

        for j in joueurs:
            j["en_jeu"]              = True
            j["enchainement_actuel"] = []
            j["casque_actuel"]       = None

        # Cherche le joueur avec le plus de points pour commencer
        meilleur_idx          = max(range(len(joueurs)), key=lambda i: joueurs[i]["points"])
        etat["_idx_courant"]  = meilleur_idx
        etat["moi"]           = joueurs[meilleur_idx]


# ─────────────────────────────────────────────────────────────────
#  Fonctions publiques
# ─────────────────────────────────────────────────────────────────

def manche_terminee(etat):
    """True si tous les joueurs ont fini cette manche."""
    return etat["_manche_finie"]


def partie_terminee(etat):
    """True si les 4 manches ont été jouées."""
    return etat["id_manche"] > NB_MANCHES or (
        etat["id_manche"] == NB_MANCHES and etat["_manche_finie"]
    )


def scores_finaux(etat):
    """Retourne {id_joueur: points}."""
    return {j["id"]: j["points"] for j in etat["joueurs"]}


def gagnant(etat):
    """Retourne l'id du gagnant (ou liste en cas d'égalité)."""
    scores  = scores_finaux(etat)
    meilleur = max(scores.values())
    gagnants = [id_j for id_j, pts in scores.items() if pts == meilleur]
    return gagnants[0] if len(gagnants) == 1 else gagnants
