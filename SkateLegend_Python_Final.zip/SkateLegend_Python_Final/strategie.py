"""
strategie.py — Stratégies de jeu pour Skate Legend.

Contient :
- JoueurStrategie : classe de base (interface imposée par le professeur)
- StrategieAleatoire : joue au hasard
- StrategieRisque    : stratégie intelligente risk-aware
- StrategieAgressive : continue presque toujours

Pour créer votre propre stratégie :
    class MaStrategie(JoueurStrategie):
        def continuer_jouer(self, votre_joueur_id, etat_partie):
            ...
        def jouer_carte(self, votre_joueur_id, etat_partie):
            ...
"""

import random


# ══════════════════════════════════════════════════════════════════
#  Classe de base (interface imposée par le professeur)
# ══════════════════════════════════════════════════════════════════

class JoueurStrategie:
    """
    Interface de base que toutes les stratégies doivent respecter.
    Par défaut : comportement aléatoire simple.
    """

    def __init__(self):
        pass

    def continuer_jouer(self, votre_joueur_id, etat_partie):
        """
        Faut-il continuer à jouer une figure ?

        Retourne :
          True  → jouer une figure (risquer la chute)
          False → s'arrêter et valider l'enchaînement
        """
        # Par défaut : continue dans 6 cas sur 7
        return random.randint(0, 6) > 0

    def jouer_carte(self, votre_joueur_id, etat_partie):
        """
        Quelle carte jouer ?

        Retourne un tuple (source, index) :
          (1, 0) → pioche gauche
          (2, 0) → pioche droite
          (0, i) → carte i de la main (i commence à 0)
        """
        # Par défaut : pioche droite
        return (2, 0)

    def piocher_carte(self, votre_joueur_id, etat_partie):
        """
        Quelle pioche choisir pour l'effet +CARTE ?

        Retourne :
          (1, 0) → pioche gauche
          (2, 0) → pioche droite
        """
        return (1, 0)

    def jouer_casque(self, votre_joueur_id, etat_partie):
        """
        Poser le jeton casque sur la dernière carte jouée ?

        Retourne :
          True  → oui, poser le casque
          False → non, garder le jeton
        """
        return False

    def notifier_choix(self, joueur_id, continuer, carte_jouee, etat_partie):
        """
        Appelé après chaque décision d'un joueur (y compris les adversaires).

        Paramètres :
          joueur_id  : id du joueur qui vient de jouer
          continuer  : True si le joueur a joué une carte, False s'il s'est arrêté
          carte_jouee: la carte jouée (dict), ou None si le joueur s'est arrêté
          etat_partie: état de la partie au moment de la décision
        """
        pass

    def notifier_pioche(self, joueur_id, carte_visible_prise):
        """
        Appelé quand un joueur pioche une carte visible (effet +CARTE).

        Paramètres :
          joueur_id          : id du joueur qui a pioché
          carte_visible_prise: la carte piochée (dict), ou None si non visible
        """
        pass


# ══════════════════════════════════════════════════════════════════
#  Stratégie aléatoire
# ══════════════════════════════════════════════════════════════════

class StrategieAleatoire(JoueurStrategie):
    """
    Joue des actions légales au hasard.
    Utile comme point de comparaison (baseline).
    """

    def __init__(self):
        super().__init__()

    def continuer_jouer(self, votre_joueur_id, etat_partie):
        return random.random() < 0.7   # continue 70% du temps

    def jouer_carte(self, votre_joueur_id, etat_partie):
        moi = etat_partie["moi"]
        options = [(1, 0), (2, 0)]
        if moi["main"]:
            for i in range(len(moi["main"])):
                options.append((0, i))
        return random.choice(options)

    def piocher_carte(self, votre_joueur_id, etat_partie):
        return random.choice([(1, 0), (2, 0)])

    def jouer_casque(self, votre_joueur_id, etat_partie):
        moi = etat_partie["moi"]
        if moi["casques_reserve"] <= 0:
            return False
        return random.random() < 0.4

    def notifier_choix(self, joueur_id, continuer, carte_jouee, etat_partie):
        pass

    def notifier_pioche(self, joueur_id, carte_visible_prise):
        pass


# ══════════════════════════════════════════════════════════════════
#  Fonctions utilitaires (utilisées par les stratégies)
# ══════════════════════════════════════════════════════════════════

def _points_enchainement(moi):
    """Calcule les points de l'enchaînement courant."""
    total = 0
    for carte in moi["enchainement_actuel"]:
        total += carte["récompense"]
    return total


def _compter_skate_casse(enchainement):
    """Compte les symboles Skate Cassé dans l'enchaînement."""
    compteur = 0
    for carte in enchainement:
        if carte["cassé"] == 1:
            compteur += 1
    return compteur


def _couleur_max(enchainement, casque_actuel):
    """
    Retourne la fréquence maximale d'une couleur dans l'enchaînement
    (en ignorant la couleur protégée par le casque).
    """
    compteur = {}
    for carte in enchainement:
        couleur = carte["couleur"]
        if couleur is None:
            continue
        if couleur == casque_actuel:
            continue
        if couleur not in compteur:
            compteur[couleur] = 0
        compteur[couleur] += 1

    if not compteur:
        return 0
    return max(compteur.values())


def _estimer_risque(moi):
    """
    Estime le risque de chute entre 0.0 et 1.0.

    Tient compte :
    - du nombre de Skate Cassé
    - de la couleur dominante (casque ignoré)
    - de la longueur de l'enchaînement
    """
    enchainement = moi["enchainement_actuel"]
    casque = moi["casque_actuel"]

    if not enchainement:
        return 0.05

    nb_casses = _compter_skate_casse(enchainement)
    risque_casse = 0.0
    if nb_casses == 1:
        risque_casse = 0.18
    elif nb_casses == 2:
        risque_casse = 0.55
    elif nb_casses >= 3:
        risque_casse = 1.0

    max_couleur = _couleur_max(enchainement, casque)
    risque_couleur = 0.0
    if max_couleur == 2:
        risque_couleur = 0.35
    elif max_couleur >= 3:
        risque_couleur = 1.0

    risque_longueur = min(0.2, len(enchainement) * 0.04)

    risque_total = risque_casse + risque_couleur + risque_longueur
    return min(1.0, risque_total)


def _meilleure_pioche(etat_partie):
    """
    Choisit la pioche avec la meilleure carte visible.
    Si aucune n'est visible, choisit la droite par défaut.
    """
    pioche = etat_partie["pioche"]

    score_gauche = -1.0
    score_droite = -1.0

    if pioche[0] is not None:
        score_gauche = float(pioche[0]["récompense"])
        if pioche[0]["cassé"] == 1:
            score_gauche -= 1.5

    if pioche[1] is not None:
        score_droite = float(pioche[1]["récompense"])
        if pioche[1]["cassé"] == 1:
            score_droite -= 1.5

    if score_gauche >= score_droite and score_gauche >= 0:
        return (1, 0)
    return (2, 0)


# ══════════════════════════════════════════════════════════════════
#  Stratégie risk-aware
# ══════════════════════════════════════════════════════════════════

class StrategieRisque(JoueurStrategie):
    """
    Stratégie intelligente qui évalue le risque avant chaque décision.

    Paramètres :
      seuil_arret      : points minimum pour envisager de s'arrêter (défaut 6)
      tolerance_risque : entre 0 (très prudent) et 1 (très agressif) (défaut 0.45)
    """

    def __init__(self, seuil_arret=6, tolerance_risque=0.45):
        super().__init__()
        self.seuil_arret      = seuil_arret
        self.tolerance_risque = tolerance_risque

    def continuer_jouer(self, votre_joueur_id, etat_partie):
        moi    = etat_partie["moi"]
        pts    = _points_enchainement(moi)
        risque = _estimer_risque(moi)

        # Toujours jouer si l'enchaînement est vide
        if pts == 0:
            return True

        # Calcule le gain marginal espéré
        import math
        gain_marginal = max(0.5, 2.5 * math.exp(-pts / 8.0))

        # Coût du risque = probabilité de chute × points perdus
        cout_risque = risque * (pts * 1.15 + 2.0)

        # Seuil de décision
        seuil = gain_marginal * (0.5 + 0.5 * self.tolerance_risque)

        if cout_risque > seuil and pts >= self.seuil_arret:
            return False

        # S'arrête si l'enchaînement est très long
        if pts >= self.seuil_arret * 1.8:
            return False

        return True

    def jouer_carte(self, votre_joueur_id, etat_partie):
        moi = etat_partie["moi"]

        # Essaie de jouer une bonne carte de la main
        if moi["main"]:
            for i, carte in enumerate(moi["main"]):
                if carte["récompense"] >= 3 and carte["cassé"] == 0:
                    return (0, i)

        # Sinon choisit la meilleure pioche
        return _meilleure_pioche(etat_partie)

    def piocher_carte(self, votre_joueur_id, etat_partie):
        return _meilleure_pioche(etat_partie)

    def jouer_casque(self, votre_joueur_id, etat_partie):
        moi    = etat_partie["moi"]
        risque = _estimer_risque(moi)

        if moi["casques_reserve"] <= 0:
            return False

        max_couleur = _couleur_max(moi["enchainement_actuel"], moi["casque_actuel"])
        return risque >= 0.32 and max_couleur >= 2

    def notifier_choix(self, joueur_id, continuer, carte_jouee, etat_partie):
        pass

    def notifier_pioche(self, joueur_id, carte_visible_prise):
        pass


# ══════════════════════════════════════════════════════════════════
#  Stratégie agressive
# ══════════════════════════════════════════════════════════════════

class StrategieAgressive(JoueurStrategie):
    """
    Continue à jouer presque toujours.
    S'arrête seulement si le risque est extrême ou l'enchaînement très long.
    """

    def __init__(self):
        super().__init__()

    def continuer_jouer(self, votre_joueur_id, etat_partie):
        moi    = etat_partie["moi"]
        pts    = _points_enchainement(moi)
        risque = _estimer_risque(moi)

        if risque >= 0.72 and pts >= 8:
            return False
        if pts >= 18:
            return False
        return True

    def jouer_carte(self, votre_joueur_id, etat_partie):
        pioche = etat_partie["pioche"]
        if pioche[1] is not None:
            return (2, 0)
        if pioche[0] is not None:
            return (1, 0)
        moi = etat_partie["moi"]
        if moi["main"]:
            return (0, 0)
        return (2, 0)

    def piocher_carte(self, votre_joueur_id, etat_partie):
        return (2, 0)

    def jouer_casque(self, votre_joueur_id, etat_partie):
        moi    = etat_partie["moi"]
        risque = _estimer_risque(moi)
        if moi["casques_reserve"] <= 0:
            return False
        return risque >= 0.45

    def notifier_choix(self, joueur_id, continuer, carte_jouee, etat_partie):
        pass

    def notifier_pioche(self, joueur_id, carte_visible_prise):
        pass
