"""
cartes.py — Données des cartes du jeu Skate Legend.

Contient :
- La liste des 120 cartes Figure (CATALOGUE_FIGURES)
- La liste des cartes Légendaires (CATALOGUE_LEGENDAIRES)
- Chaque carte est un dictionnaire simple
"""

# ─────────────────────────────────────────────────────────────────
#  Format d'une carte (dictionnaire)
# ─────────────────────────────────────────────────────────────────
#
#  {
#    "nom"       : str   — nom de la figure
#    "couleur"   : str   — "rouge" | "vert" | "bleu" | "jaune" | None
#    "récompense": int   — points de prestige
#    "piocher"   : int   — 1 si effet +CARTE, sinon 0
#    "rejouer"   : int   — 1 si effet REJOUE, sinon 0
#    "visible"   : int   — 1 si effet RÉVÈLE, sinon 0
#    "cassé"     : int   — 1 si symbole Skate Cassé, sinon 0
#    "condition" : str | None — condition légendaire (None pour les figures)
#  }
#
# ─────────────────────────────────────────────────────────────────


def _figure(nom, couleur, recompense, piocher=0, rejouer=0, visible=0, casse=0):
    """Crée un dictionnaire représentant une carte Figure."""
    return {
        "nom":        nom,
        "couleur":    couleur,
        "récompense": recompense,
        "piocher":    piocher,
        "rejouer":    rejouer,
        "visible":    visible,
        "cassé":      casse,
        "condition":  None,
    }


def _legendaire(nom, couleur, recompense, condition):
    """Crée un dictionnaire représentant une carte Légendaire."""
    return {
        "nom":        nom,
        "couleur":    couleur,
        "récompense": recompense,
        "piocher":    0,
        "rejouer":    0,
        "visible":    0,
        "cassé":      0,
        "condition":  condition,
    }


# ─────────────────────────────────────────────────────────────────
#  120 cartes Figure  (30 par couleur)
# ─────────────────────────────────────────────────────────────────

CATALOGUE_FIGURES = [

    # ── ROUGE ────────────────────────────────────────────────────
    _figure("Ollie",          "rouge", 1),
    _figure("Pop Shove-it",   "rouge", 1),
    _figure("Nollie",         "rouge", 1),
    _figure("Manual",         "rouge", 1),
    _figure("Fakie",          "rouge", 1),
    _figure("Slam",           "rouge", 1, casse=1),
    _figure("Bail",           "rouge", 1, casse=1),
    _figure("Close Call",     "rouge", 1, piocher=1),
    _figure("Kickflip",       "rouge", 2),
    _figure("Heelflip",       "rouge", 2),
    _figure("Varial",         "rouge", 2),
    _figure("Inward",         "rouge", 2),
    _figure("Hard Flip",      "rouge", 2, visible=1),
    _figure("Red Crack",      "rouge", 2, piocher=1),
    _figure("Board Snap",     "rouge", 2, casse=1),
    _figure("Noseslide",      "rouge", 2),
    _figure("360 Flip",       "rouge", 3),
    _figure("Blunt",          "rouge", 3),
    _figure("Noseblunt",      "rouge", 3),
    _figure("Suski Grind",    "rouge", 3, rejouer=1),
    _figure("Smith Grind",    "rouge", 3),
    _figure("K-Grind",        "rouge", 3, casse=1),
    _figure("Bluntslide",     "rouge", 3),
    _figure("Laser Flip",     "rouge", 4),
    _figure("Hardflip BS",    "rouge", 4),
    _figure("Red Thunder",    "rouge", 4, casse=1),
    _figure("Inward FS",      "rouge", 4),
    _figure("900°",           "rouge", 5),
    _figure("Mega Ramp",      "rouge", 5),
    _figure("Red Legend",     "rouge", 5),

    # ── VERT ─────────────────────────────────────────────────────
    _figure("Drop In",        "vert",  1),
    _figure("Pump",           "vert",  1),
    _figure("Carve",          "vert",  1),
    _figure("Pivot",          "vert",  1),
    _figure("Stall",          "vert",  1),
    _figure("Ditch Bail",     "vert",  1, casse=1),
    _figure("Curb Slam",      "vert",  1, casse=1),
    _figure("Green Reveal",   "vert",  1, visible=1),
    _figure("Boardslide",     "vert",  2),
    _figure("Lipslide",       "vert",  2),
    _figure("Tailslide",      "vert",  2),
    _figure("Nosegrind",      "vert",  2),
    _figure("5-0 Grind",      "vert",  2, piocher=1),
    _figure("Feeble Grind",   "vert",  2, casse=1),
    _figure("Crook",          "vert",  2, visible=1),
    _figure("Willy Grind",    "vert",  2),
    _figure("Darkslide",      "vert",  3),
    _figure("Salad Grind",    "vert",  3),
    _figure("Overcrook",      "vert",  3),
    _figure("GreenReplay",    "vert",  3, rejouer=1),
    _figure("Halfcab Flip",   "vert",  3),
    _figure("Caballerial",    "vert",  3, casse=1),
    _figure("Switch Flip",    "vert",  3),
    _figure("Nollie Flip",    "vert",  4),
    _figure("Nollie Heel",    "vert",  4),
    _figure("GreenCrack",     "vert",  4, casse=1),
    _figure("FullCab Flip",   "vert",  4),
    _figure("720 Flip",       "vert",  5),
    _figure("Green Storm",    "vert",  5),
    _figure("Green Legend",   "vert",  5),

    # ── BLEU ─────────────────────────────────────────────────────
    _figure("Axle Stall",     "bleu",  1),
    _figure("Rock n Roll",    "bleu",  1),
    _figure("Disaster",       "bleu",  1),
    _figure("Invert",         "bleu",  1),
    _figure("Egg Plant",      "bleu",  1),
    _figure("Slam Blue",      "bleu",  1, casse=1),
    _figure("Bail Blue",      "bleu",  1, casse=1),
    _figure("Blue Draw",      "bleu",  1, piocher=1),
    _figure("Frontside Air",  "bleu",  2),
    _figure("Backside Air",   "bleu",  2),
    _figure("Lien Air",       "bleu",  2),
    _figure("Mute Air",       "bleu",  2),
    _figure("Stalefish",      "bleu",  2, rejouer=1),
    _figure("Nosegrab",       "bleu",  2, casse=1),
    _figure("Tailgrab",       "bleu",  2, visible=1),
    _figure("Melon Grab",     "bleu",  2),
    _figure("Crooked Air",    "bleu",  3),
    _figure("Crippler",       "bleu",  3),
    _figure("McTwist",        "bleu",  3),
    _figure("BlueReplay",     "bleu",  3, rejouer=1),
    _figure("Kickflip Air",   "bleu",  3),
    _figure("Varial Hflip",   "bleu",  3, casse=1),
    _figure("Bigflip Air",    "bleu",  3),
    _figure("FS Blunt Air",   "bleu",  4),
    _figure("BS Noseblunt",   "bleu",  4),
    _figure("Blue Thunder",   "bleu",  4, casse=1),
    _figure("Rad Air",        "bleu",  4),
    _figure("1080°",          "bleu",  5),
    _figure("Blue Storm",     "bleu",  5),
    _figure("Blue Legend",    "bleu",  5),

    # ── JAUNE ────────────────────────────────────────────────────
    _figure("Handplant",      "jaune", 1),
    _figure("Ho-Ho",          "jaune", 1),
    _figure("Nosepick",       "jaune", 1),
    _figure("Footplant",      "jaune", 1),
    _figure("Andrecht",       "jaune", 1),
    _figure("Slam Jaune",     "jaune", 1, casse=1),
    _figure("Bail Jaune",     "jaune", 1, casse=1),
    _figure("Yellow Draw",    "jaune", 1, piocher=1),
    _figure("Madonna",        "jaune", 2),
    _figure("Saran Wrap",     "jaune", 2),
    _figure("Christ Air",     "jaune", 2),
    _figure("Japan Air",      "jaune", 2),
    _figure("YellowReveal",   "jaune", 2, visible=1),
    _figure("YellowDraw2",    "jaune", 2, piocher=1),
    _figure("Roast Beef",     "jaune", 2, casse=1),
    _figure("Benihana",       "jaune", 2),
    _figure("540°",           "jaune", 3),
    _figure("720° Flip",      "jaune", 3),
    _figure("Airwalk",        "jaune", 3),
    _figure("YelReplay",      "jaune", 3, rejouer=1),
    _figure("Gymnast Plant",  "jaune", 3),
    _figure("Cosmic Air",     "jaune", 3, casse=1),
    _figure("Haslam",         "jaune", 3),
    _figure("540 Flip",       "jaune", 4),
    _figure("900 Flip",       "jaune", 4),
    _figure("Yellow Thunder", "jaune", 4, casse=1),
    _figure("Loop",           "jaune", 4),
    _figure("1260°",          "jaune", 5),
    _figure("Yellow Storm",   "jaune", 5),
    _figure("Yellow Legend",  "jaune", 5),
]


# ─────────────────────────────────────────────────────────────────
#  10 cartes Légendaires
# ─────────────────────────────────────────────────────────────────

CATALOGUE_LEGENDAIRES = [
    _legendaire("Perfect Landing", None,    5, None),
    _legendaire("360°",            "rouge", 4, "2 rouges"),
    _legendaire("Casper Slide",    None,    3, "2 meme couleur"),
    _legendaire("180°",            None,    3, "4 cartes"),
    _legendaire("720°",            None,    5, "5 cartes"),
    _legendaire("900°",            "vert",  4, "1 vert 1 jaune"),
    _legendaire("1080°",           "bleu",  6, "3 couleurs"),
    _legendaire("Airwalk Grab",    "jaune", 4, "2 casses"),
    _legendaire("Darkflip",        None,    3, "2 meme couleur"),
    _legendaire("Mega Trick",      None,    5, "5 cartes"),
]
