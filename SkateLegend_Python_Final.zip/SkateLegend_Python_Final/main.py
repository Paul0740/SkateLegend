"""
main.py — Point d'entrée principal du jeu Skate Legend.

Usage :
    python main.py            → menu principal
    python main.py --jouer    → partie interactive immédiate
    python main.py --demo     → partie démo entre IA

Fichiers du projet :
    cartes.py    — données des 120 cartes + légendaires
    moteur.py    — logique du jeu (règles, tours, manches)
    strategie.py — interface JoueurStrategie + 3 stratégies
    main.py      — ce fichier (menu + affichage)
"""

import os
import random
import sys
import time

from moteur import (
    nouvelle_partie, jouer_tour, manche_terminee,
    partie_terminee, scores_finaux, gagnant,
    _construire_etat_public,
)
from strategie import (
    JoueurStrategie,
    StrategieAleatoire,
    StrategieRisque,
    StrategieAgressive,
)


# ─────────────────────────────────────────────────────────────────
#  Couleurs terminal (ANSI)
# ─────────────────────────────────────────────────────────────────

RESET  = "\033[0m"
GRAS   = "\033[1m"
DIM    = "\033[2m"
CYAN   = "\033[36m"
JAUNE  = "\033[33m"
VERT   = "\033[32m"
ROUGE  = "\033[31m"
BLEU   = "\033[34m"


def activer_ansi():
    if sys.platform == "win32":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            h = k32.GetStdHandle(-11)
            m = ctypes.c_uint32()
            k32.GetConsoleMode(h, ctypes.byref(m))
            k32.SetConsoleMode(h, m.value | 0x0004)
        except Exception:
            pass


def effacer():
    os.system("cls" if os.name == "nt" else "clear")


def ligne(char="─", largeur=56, couleur=CYAN):
    print(f"{couleur}{char * largeur}{RESET}")


def attendre(msg="  [Appuyez sur Entrée pour continuer...]"):
    try:
        input(f"\n{DIM}{msg}{RESET}")
    except EOFError:
        pass


def demander_entier(invite, mini, maxi):
    while True:
        try:
            valeur = int(input(invite).strip())
            if mini <= valeur <= maxi:
                return valeur
            print(f"  {ROUGE}Entrez un nombre entre {mini} et {maxi}.{RESET}")
        except (ValueError, EOFError):
            print(f"  {ROUGE}Entrée invalide.{RESET}")


# ─────────────────────────────────────────────────────────────────
#  Affichage d'une carte
# ─────────────────────────────────────────────────────────────────

COULEURS_ANSI = {
    "rouge": "\033[31m",
    "vert":  "\033[32m",
    "jaune": "\033[33m",
    "bleu":  "\033[34m",
    None:    "\033[37m",
}


def afficher_carte(carte):
    if carte is None:
        return "(vide)"

    couleur_ansi = COULEURS_ANSI.get(carte["couleur"], "\033[37m")
    nom_couleur  = carte["couleur"] if carte["couleur"] else "grise"
    casse        = f" |{ROUGE}X{RESET}"     if carte["cassé"]    else ""
    effet        = ""
    if carte["piocher"] == 1:
        effet = f" |{BLEU}+CARTE{RESET}"
    elif carte["rejouer"] == 1:
        effet = f" |{BLEU}REJOUE{RESET}"
    elif carte["visible"] == 1:
        effet = f" |{BLEU}RÉVÈLE{RESET}"
    legendaire = f"{JAUNE}★ {RESET}" if carte["condition"] is not None else ""

    return (f"[{legendaire}{carte['nom']} | "
            f"{couleur_ansi}{nom_couleur}{RESET} | "
            f"{carte['récompense']}pts{casse}{effet}]")


# ─────────────────────────────────────────────────────────────────
#  Affichage de l'état de la partie
# ─────────────────────────────────────────────────────────────────

def afficher_etat(etat, noms_joueurs):
    print(f"\n{CYAN}{GRAS}── Manche {etat['id_manche']}/4 ──────────────────────────{RESET}")

    p0 = afficher_carte(etat["pioche"][0]) if etat["pioche"][0] else "(face cachée)"
    p1 = afficher_carte(etat["pioche"][1]) if etat["pioche"][1] else "(face cachée)"
    taille0 = len(etat["_pile0"])
    taille1 = len(etat["_pile1"])
    print(f"Pioches : [{taille0} cartes | {p0}]  [{taille1} cartes | {p1}]")

    if etat["cartes_legendaires"]:
        r = etat["cartes_legendaires"][0]
        print(f"{JAUNE}★ Récompense : {r['nom']} ({r['récompense']} pts){RESET}")

    print()

    idx_courant = etat["_idx_courant"]
    for j in etat["joueurs"]:
        fleche = f"{GRAS}▶ {RESET}" if j["id"] == idx_courant else "  "
        statut = f"{VERT}[EN JEU]{RESET}" if j["en_jeu"] else f"{ROUGE}[STOP]{RESET}"
        nom    = noms_joueurs[j["id"]]
        pts_seq = sum(c["récompense"] for c in j["enchainement_actuel"])
        print(f"{fleche}{statut} {GRAS}{nom}{RESET}"
              f"  score={j['points']}  seq={pts_seq}pts"
              f"  casques={j['casques_reserve']}")


def afficher_tour_joueur(joueur, nom):
    print(f"\n{GRAS}{CYAN}═══ Votre tour, {nom} ═══{RESET}")

    print(f"\n{GRAS}Votre main :{RESET}")
    if joueur["main"]:
        for i, carte in enumerate(joueur["main"]):
            print(f"  [{i}] {afficher_carte(carte)}")
    else:
        print(f"  {DIM}(vide){RESET}")

    print(f"\n{GRAS}Votre enchaînement :{RESET}")
    if joueur["enchainement_actuel"]:
        for carte in joueur["enchainement_actuel"]:
            print(f"  {afficher_carte(carte)}")
        pts   = sum(c["récompense"] for c in joueur["enchainement_actuel"])
        casse = sum(1 for c in joueur["enchainement_actuel"] if c["cassé"])
        casque_info = ""
        if joueur["casque_actuel"]:
            casque_info = f"  {JAUNE}Casque : {joueur['casque_actuel']}{RESET}"
        print(f"  {DIM}Total : {pts} pts  |  Skate Cassé : {casse}/3{casque_info}{RESET}")
    else:
        print(f"  {DIM}(vide — jouez votre première figure){RESET}")


# ─────────────────────────────────────────────────────────────────
#  Stratégie humaine (saisie clavier)
# ─────────────────────────────────────────────────────────────────

class StrategieHumaine(JoueurStrategie):

    def __init__(self, nom):
        super().__init__()
        self.nom = nom

    def continuer_jouer(self, votre_joueur_id, etat_partie):
        print(f"\n{GRAS}Que voulez-vous faire ?{RESET}")
        print("  [1] Jouer une figure")
        print("  [2] S'arrêter et valider l'enchaînement")
        choix = demander_entier("Votre choix : ", 1, 2)
        return choix == 1

    def jouer_carte(self, votre_joueur_id, etat_partie):
        moi    = etat_partie["moi"]
        pioche = etat_partie["pioche"]

        print(f"\n{GRAS}Choisissez une source :{RESET}")
        info0 = afficher_carte(pioche[0]) if pioche[0] else "face cachée"
        info1 = afficher_carte(pioche[1]) if pioche[1] else "face cachée"
        print(f"  [1] Pioche gauche  ({info0})")
        print(f"  [2] Pioche droite  ({info1})")
        nb_options = 2

        if moi["main"]:
            print(f"  [3] Depuis ma main")
            nb_options = 3

        choix = demander_entier("Source : ", 1, nb_options)

        if choix == 1:
            return (1, 0)
        if choix == 2:
            return (2, 0)

        for i, carte in enumerate(moi["main"]):
            print(f"  [{i}] {afficher_carte(carte)}")
        idx = demander_entier(f"Carte [0-{len(moi['main'])-1}] : ",
                              0, len(moi["main"]) - 1)
        return (0, idx)

    def piocher_carte(self, votre_joueur_id, etat_partie):
        pioche = etat_partie["pioche"]
        print(f"\n{BLEU}Effet +CARTE ! Choisissez une pioche :{RESET}")
        info0 = afficher_carte(pioche[0]) if pioche[0] else "face cachée"
        info1 = afficher_carte(pioche[1]) if pioche[1] else "face cachée"
        print(f"  [1] Pioche gauche  ({info0})")
        print(f"  [2] Pioche droite  ({info1})")
        choix = demander_entier("Source : ", 1, 2)
        return (choix, 0)

    def jouer_casque(self, votre_joueur_id, etat_partie):
        moi = etat_partie["moi"]
        if moi["casques_reserve"] <= 0:
            return False
        print(f"\n{JAUNE}Voulez-vous poser votre jeton Casque ? [1=Oui / 2=Non]{RESET}")
        choix = demander_entier("Votre choix : ", 1, 2)
        return choix == 1

    def notifier_choix(self, joueur_id, continuer, carte_jouee, etat_partie):
        pass

    def notifier_pioche(self, joueur_id, carte_visible_prise):
        pass


# ─────────────────────────────────────────────────────────────────
#  Partie interactive
# ─────────────────────────────────────────────────────────────────

def partie_interactive():
    effacer()
    print(f"\n{JAUNE}{GRAS}")
    print("╔══════════════════════════════════════════════╗")
    print("║       SKATE LEGEND  —  Nouvelle partie       ║")
    print("╚══════════════════════════════════════════════╝")
    print(RESET)

    nb_humains = demander_entier("Nombre de joueurs humains (1-3) : ", 1, 3)
    noms = []
    for i in range(nb_humains):
        nom = input(f"  Nom du skater {i+1} : ").strip()
        if not nom:
            nom = f"Skater{i+1}"
        noms.append(nom)

    nb_ia = 0
    if nb_humains < 4:
        nb_ia = demander_entier(
            f"Nombre d'adversaires IA (0-{4-nb_humains}) : ",
            0, 4 - nb_humains
        )

    strategies      = []
    noms_complet    = list(noms)

    for nom in noms:
        strategies.append(StrategieHumaine(nom))

    noms_ia = ["Alice", "Bob", "Chloé", "David"]
    for i in range(nb_ia):
        nom_ia = noms_ia[i]
        noms_complet.append(nom_ia)
        print(f"\n{GRAS}Difficulté pour {nom_ia} :{RESET}")
        print("  [1] Aléatoire   [2] Prudente   [3] Agressive")
        choix = demander_entier("Choix : ", 1, 3)
        if choix == 1:
            strategies.append(StrategieAleatoire())
        elif choix == 2:
            strategies.append(StrategieRisque())
        else:
            strategies.append(StrategieAgressive())

    nb_total = nb_humains + nb_ia
    etat = nouvelle_partie(nb_total)

    attendre("  [Appuyez sur Entrée pour commencer...]")

    while not partie_terminee(etat):
        while not manche_terminee(etat):
            idx       = etat["_idx_courant"]
            joueur    = etat["joueurs"][idx]
            strategie = strategies[idx]
            nom       = noms_complet[idx]

            if isinstance(strategie, StrategieHumaine):
                effacer()
                afficher_etat(etat, noms_complet)
                afficher_tour_joueur(joueur, nom)
                print()

            jouer_tour(etat, strategie)

            if isinstance(strategie, StrategieHumaine):
                if not joueur["en_jeu"]:
                    if not joueur["enchainement_actuel"] and joueur["casque_actuel"] is None:
                        print(f"\n{ROUGE}{GRAS}💥 CHUTE ! Vous perdez votre enchaînement !{RESET}")
                        print(f"Vous recevez un jeton Casque. Total : {joueur['casques_reserve']}")
                    attendre()
            else:
                if not joueur["en_jeu"]:
                    print(f"  {nom} a terminé son tour.")

        print(f"\n{CYAN}{'─'*50}")
        print(f"  Fin de la manche {etat['id_manche'] - 1}{RESET}")
        for j in sorted(etat["joueurs"], key=lambda x: -x["points"]):
            print(f"    {noms_complet[j['id']]} : {GRAS}{j['points']} pts{RESET}")
        attendre()

    effacer()
    print(f"\n{JAUNE}{GRAS}")
    print("╔══════════════════════════════════════════════╗")
    print("║              FIN DE LA PARTIE                ║")
    print("╚══════════════════════════════════════════════╝")
    print(RESET)

    scores    = scores_finaux(etat)
    id_win    = gagnant(etat)
    for id_j, pts in sorted(scores.items(), key=lambda x: -x[1]):
        nom     = noms_complet[id_j]
        couronne = f" {JAUNE}👑{RESET}" if id_j == id_win else ""
        print(f"  {GRAS}{nom}{RESET} : {pts} pts{couronne}")

    nom_gagnant = noms_complet[id_win] if isinstance(id_win, int) else "Égalité"
    print(f"\n{VERT}🏆 {GRAS}{nom_gagnant}{RESET}{VERT} devient la nouvelle SKATE LEGEND !{RESET}\n")


# ─────────────────────────────────────────────────────────────────
#  Partie démo (IA vs IA, narée)
# ─────────────────────────────────────────────────────────────────

def demo():
    noms   = ["Prudente", "Agressive", "Aléatoire"]
    strats = [StrategieRisque(), StrategieAgressive(), StrategieAleatoire()]

    effacer()
    print(f"\n{JAUNE}{GRAS}📺  PARTIE DÉMO — les IA s'affrontent !{RESET}\n")
    print(f"  Joueurs : {', '.join(f'{CYAN}{n}{RESET}' for n in noms)}\n")
    ligne()

    etat           = nouvelle_partie(3)
    manche_affichee = 0

    while not partie_terminee(etat):

        if etat["id_manche"] != manche_affichee:
            manche_affichee = etat["id_manche"]
            print(f"\n{CYAN}{GRAS}╔══════════════╗")
            print(f"║  MANCHE {manche_affichee} / 4  ║")
            print(f"╚══════════════╝{RESET}")
            if etat["cartes_legendaires"]:
                r = etat["cartes_legendaires"][0]
                print(f"  {JAUNE}★ Récompense : {r['nom']} ({r['récompense']} pts){RESET}")

        while not manche_terminee(etat):
            idx      = etat["_idx_courant"]
            joueur   = etat["joueurs"][idx]
            nom      = noms[idx]
            pts_avant = joueur["points"]

            jouer_tour(etat, strats[idx])

            if not joueur["en_jeu"]:
                pts_apres = joueur["points"]
                if pts_apres > pts_avant:
                    gain = pts_apres - pts_avant
                    print(f"  {VERT}✓ {nom} s'arrête et gagne {gain} pts "
                          f"(total : {pts_apres}){RESET}")
                else:
                    print(f"  {ROUGE}💥 {nom} chute ! "
                          f"(casques : {joueur['casques_reserve']}){RESET}")

        print(f"\n{CYAN}── Fin de la manche {manche_affichee} ──{RESET}")
        for j in sorted(etat["joueurs"], key=lambda x: -x["points"]):
            print(f"    {noms[j['id']]} : {GRAS}{j['points']} pts{RESET}")
        time.sleep(0.4)

    print(f"\n{JAUNE}{GRAS}─── Scores finaux ───────────────────────{RESET}")
    scores = scores_finaux(etat)
    id_win = gagnant(etat)
    for id_j, pts in sorted(scores.items(), key=lambda x: -x[1]):
        couronne = f" {JAUNE}👑{RESET}" if id_j == id_win else ""
        print(f"  {GRAS}{noms[id_j]}{RESET} : {pts} pts{couronne}")
    print()


# ─────────────────────────────────────────────────────────────────
#  Menu principal
# ─────────────────────────────────────────────────────────────────

def afficher_menu():
    effacer()
    print(f"\n{JAUNE}{GRAS}")
    print("╔══════════════════════════════════════════════╗")
    print("║         S K A T E   L E G E N D              ║")
    print("║         New Tokyo  —  Compétition            ║")
    print("╚══════════════════════════════════════════════╝")
    print(RESET)
    ligne()
    print(f"  {GRAS}MENU PRINCIPAL{RESET}\n")
    print(f"    [{CYAN}{GRAS}1{RESET}]  🎮  Jouer en interactif")
    print(f"    [{CYAN}{GRAS}2{RESET}]  📺  Partie démo            (IA vs IA)")
    print(f"    [{ROUGE}{GRAS}0{RESET}]  Quitter")
    print()
    ligne()


def main():
    activer_ansi()

    # Flags CLI
    if len(sys.argv) >= 2:
        flag = sys.argv[1].lower()
        if flag == "--jouer":
            partie_interactive()
            return
        elif flag == "--demo":
            demo()
            return

    # Menu interactif
    while True:
        afficher_menu()
        choix = input(f"  {GRAS}Votre choix : {RESET}").strip()

        if choix == "1":
            partie_interactive()
            attendre()

        elif choix == "2":
            demo()
            attendre()

        elif choix in ("0", "q", "quitter"):
            effacer()
            print(f"\n{JAUNE}À bientôt sur le ramp ! 🛹{RESET}\n")
            sys.exit(0)

        else:
            print(f"  {ROUGE}Choix invalide.{RESET}")
            time.sleep(0.7)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{DIM}Interrompu.{RESET}\n")
        sys.exit(0)
